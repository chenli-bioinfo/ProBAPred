﻿package com.boredou.mercury.util;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class SequenceFeatureCalculation {
	
	public static List<String> add(){
		List<String> list = new ArrayList<String>();
		list.add("1AHW_AB:C");
		list.add("1BJ1_HL:VW");
		list.add("1BVK_DE:F");
		list.add("1DQJ_AB:C");
		list.add("1E6J_HL:P");
		list.add("1FSK_BC:A");
		list.add("1JPS_HL:T");
		list.add("1KXQ_H:A");
		list.add("1NCA_HL:N");
		list.add("1P2C_AB:C");
		list.add("1VFB_AB:C");
		list.add("1WEJ_HL:F");
		list.add("2I25_N:L");
		list.add("2JEL_HL:P");
		list.add("2VIR_AB:C");
		list.add("1ACB_E:I");
		list.add("1AVX_A:B");
		list.add("1BRS_A:D");
		list.add("1BUH_A:B");
		list.add("1BVN_P:T");
		list.add("1DFJ_E:I");
		list.add("1EAW_A:B");
		list.add("1EMV_A:B");
		list.add("1EZU_C:AB");
		list.add("1F34_A:B");
		list.add("1FLE_E:I");
		list.add("1GXD_A:C");
		list.add("1JIW_P:I");
		list.add("1JTG_B:A");
		list.add("1MAH_A:F");
		list.add("1NB5_AP:I");
		list.add("1OPH_A:B");
		list.add("1PXV_A:C");
		list.add("1R0R_E:I");
		list.add("1YVB_A:I");
		list.add("1ZLI_A:B");
		list.add("2ABZ_B:E");
		list.add("2B42_A:B");
		list.add("2J0T_A:D");
		list.add("2O3B_A:B");
		list.add("2OUL_A:B");
		list.add("2PTC_E:I");
		list.add("2SIC_E:I");
		list.add("2SNI_E:I");
		list.add("2UUY_A:B");
		list.add("3SGB_E:I");
		list.add("1E6E_A:B");
		list.add("1EWY_A:C");
		list.add("1F6M_A:C");
		list.add("1GLA_G:F");
		list.add("1IJK_A:BC");
		list.add("1JMO_A:HL");
		list.add("1JWH_CD:A");
		list.add("1KKL_ABC:H");
		list.add("1M10_A:B");
		list.add("1NW9_B:A");
		list.add("1OC0_A:B");
		list.add("1R6Q_A:C");
		list.add("1US7_A:B");
		list.add("1WDW_BD:A");
		list.add("1ZM4_A:B");
		list.add("2A9K_A:B");
		list.add("2MTA_HL:A");
		list.add("2OOB_A:B");
		list.add("2OOR_AB:C");
		list.add("2PCC_A:B");
		list.add("1A2K_C:AB");
		list.add("1E96_A:B");
		list.add("1FQJ_A:B");
		list.add("1GRN_A:B");
		list.add("1HE8_B:A");
		list.add("1I2M_A:B");
		list.add("1I4D_D:AB");
		list.add("1IBR_A:B");
		list.add("1K5D_AB:C");
		list.add("1LFD_B:A");
		list.add("1NVU_Q:S");
		list.add("1WQ1_R:G");
		list.add("1Z0K_A:B");
		list.add("2FJU_B:A");
		list.add("3CPH_G:A");
		list.add("1NVU_R:S");
		list.add("1E4K_AB:C");
		list.add("1EER_A:BC");
		list.add("1HCF_AB:X");
		list.add("1KAC_A:B");
		list.add("1KTZ_A:B");
		list.add("1PVH_A:B");
		list.add("1RV6_VW:X");
		list.add("1T6B_X:Y");
		list.add("2AJF_A:E");
		list.add("2HLE_A:B");
		list.add("2I9B_E:A");
		list.add("2NYZ_AB:D");
		list.add("1MLC_AB:E");
		list.add("2VIS_AB:C");
		list.add("1AY7_A:B");
		list.add("1CBW_ABC:D");
		list.add("2PCB_A:B");
		list.add("2TGP_Z:I");
		list.add("2WPT_A:B");
		list.add("1AVZ_B:C");
		list.add("2AQ3_A:B");
		list.add("1ATN_A:D");
		list.add("1DE4_AB:CF");
		list.add("1FC2_C:D");
		list.add("1H1V_A:G");
		list.add("1IB1_AB:E");
		list.add("1KLU_AB:D");
		list.add("1KXP_A:D");
		list.add("1XQS_A:C");
		list.add("2B4J_AB:C");
		list.add("2C0L_A:B");
		list.add("2VDB_A:B");
		list.add("1AKJ_AB:DE");
		list.add("1MQ8_A:B");
		list.add("1RLB_ABCD:E");
		list.add("1XD3_A:B");
		list.add("1ZHI_A:B");
		list.add("2BTF_A:P");
		list.add("2HQS_A:H");
		list.add("2HRK_A:B");
		list.add("2OZA_B:A");
		list.add("3BP8_AB:C");
		list.add("1AK4_A:D");
		list.add("1B6C_A:B");
		list.add("1EFN_B:A");
		list.add("1FFW_A:B");
		list.add("1GCQ_B:C");
		list.add("1GPW_A:B");
		list.add("1H9D_A:B");
		list.add("1QA9_A:B");
		list.add("1S1Q_A:B");
		list.add("2GOX_A:B");
		list.add("3BZD_A:B");
		return list;
	}
	
	public static Map<String, Float> CountMap(String string) {
		Map<String, Float> count = new HashMap<String, Float>();
		    for(int i=0;i<string.length();i++){ 	 //计数
				  String subStr = string.substring(i, i+1);
				  if(!count.containsKey(subStr)){
					 count.put(subStr,  (float) 1);
				  }else{
					 count.put(subStr, count.get(subStr)+1);
				  }
		    }
		return count;
	}
	
	public static void main(String[] args) throws FileNotFoundException, IOException{
		String [] fasta =new String[]{"A", "R","N","D","C","Q","E","G","H","I","L","K","M","F","P","S","T","W","Y","V",};
		List<String []> dataList = new ArrayList<String []>();
		InputStream is = new FileInputStream("c:\\544.txt");
		StringBuffer allAmino = new StringBuffer();
		byte[] buffer = new byte[1000];
		int length = 0;
		while(-1 != (length = is.read(buffer, 0, 1000))){
			String str = new String(buffer,0, length);
			allAmino.append(str.replaceAll("\r|\n", "  "));
		}
		is.close();
		System.out.println(allAmino);
		
		String regex1 = "(I    A/L     R/K     N/M     D/F     C/P     Q/S     E/T     G/W     H/Y     I/V)(.*?)(//)";
    	Pattern pattern = Pattern.compile(regex1);
		Matcher matcher = pattern.matcher(allAmino);
	    
		while(matcher.find()){
			String oneSpace = matcher.group(2);
			String subSpace = null;
			for (int i = 0; i < 5; i++) {
				String temp = oneSpace.replaceAll("  ", " ");
				oneSpace = temp;
			}
			for(int i=0;i<oneSpace.length();i++){
			String subStr = oneSpace.substring(i, i+1);
				if(" " .equals(subStr)){
					continue;
				}else{
					subSpace= oneSpace.substring(i, oneSpace.length());
					break;
				}
			}
			String[] b = subSpace.split(" ");
			dataList.add(b);
		}
		
		BufferedReader io = new BufferedReader(new FileReader("c:\\48.txt"));
		String valueString = null;
		   while ((valueString=io.readLine())!=null){
			   String[] c = valueString.split(" ");
			   dataList.add(c);
		   }   
		io.close();
		System.out.println("dataList.size()------"+dataList.size());
		/*System.out.println(dataList.size()+"list长度");//544个数组放在这个list里
	    for (int i = 0; i < dataList.size(); i++) {
	    	for (int j = 0; j < dataList.get(i).length; j++) {
	    		System.out.println(dataList.get(i)[j] + "-------第"+(j+1)+"个");
			}
		}*/
		Map<String, List<String>> map = new HashMap<String, List<String>>();
		List<List<String>> chainList = new ArrayList<List<String>>();
	
		List<String> list = add();
		
		for (int i = 0; i < list.size(); i++) {
			List<String> list2 = new ArrayList<String>();
			String pdb=list.get(i).substring(0, 4);
			URL url = new URL("http://www.rcsb.org/pdb/download/viewFastaFiles.do?structureIdList=" + pdb + "&compressionType=uncompressed");//扒页面
			BufferedReader br = new BufferedReader(new InputStreamReader(url.openStream()));
			String line = null;
			StringBuffer allaqe = new StringBuffer();
			while(null != (line = br.readLine())){
				allaqe.append(line.replaceAll("\\|", ""));
			}
			br.close();
		//	System.out.println("获得该pdb的页面内容\n"+allaqe);
			
			String	former = null ;
			String	latter = null ;
			Pattern pattern3 = Pattern.compile("\\w{5}(\\w*)[:](\\w*)");//解析2个蛋白质
			Matcher matcher3 = pattern3.matcher(list.get(i));
			if(matcher3.find()){
				former = matcher3.group(1);
				latter = matcher3.group(2);
			}
			String former1Temp = "";
			char[] former1 = former.toCharArray();//前一种的蛋白质chain
		    for (int j = 0;j < former1.length;j ++){
		    	String regex = "(>"+pdb+")[:]("+String.valueOf(former1[j])+"PDBIDCHAINSEQUENCE)(\\w*)";
		    	Pattern pattern2 = Pattern.compile(regex);
				Matcher matcher2 = pattern2.matcher(allaqe);
				if(matcher2.find()){
					former1Temp = former1Temp + matcher2.group(3);
				//	System.out.println(pdb +"_"+ String.valueOf(former1[j])+ "找到该chain序列" );
				}
		    }
		    list2.add(former1Temp);
		    String latter2Temp = "";
		    char[] latter2 = latter.toCharArray();//后一种的蛋白质chain
		    for (int k = 0;k < latter2.length;k ++){
		    	String regex = "(>"+pdb+")[:]("+String.valueOf(latter2[k])+"PDBIDCHAINSEQUENCE)(\\w*)";
		    	Pattern pattern2 = Pattern.compile(regex);
				Matcher matcher2 = pattern2.matcher(allaqe);
				if(matcher2.find()){
					latter2Temp = latter2Temp + matcher2.group(3);
				//	System.out.println(pdb +"_"+ String.valueOf(former1[j])+ "找到该chain序列" );
				}
		    }
		    list2.add(latter2Temp);
			map.put(list.get(i), list2);
			chainList.add(list2);
		}
			System.out.println("chainList.size() "+chainList.size());	
		/*for (List<String> list2 : chainList) {
			for (String string : list2) {
				System.out.println(string);
			}
			System.out.println("----------------");
		}*/
		//System.out.println("-------------------");
		FileWriter fw = new FileWriter("C:\\SequenceFeatureCalculation.csv");
		
		for(int d = 0; d < chainList.size(); d++){
		     List<String> test = chainList.get(d);
		     StringBuffer csvstr = new StringBuffer();
		    for (int n = 0; n < dataList.size(); n++) { 
		    	/*for(Map.Entry<String, Float> entry1:count.entrySet()){
		    	 System.out.println("计数"+entry1.getKey()+"-------"+ entry1.getValue());    
		    	}
		        System.out.println("<<<<<<<<<<<<<<<<"+count.size()+">>>>>>>>>>>>>>>>>>>>>>>" );*/
		    	// System.out.println(string);
		    	 for (int e = 0; e < test.size(); e++) {
		    		String string= test.get(e);
				    Map<String, Float> count = CountMap(string);
		 		    Map<String, String> temp = new HashMap<String, String>();
		 			for(Map.Entry<String, Float> entry2:count.entrySet()){
		 				String compute = entry2.getKey();
		 				switch (compute){
		 				case "A" :
		 					if("NA".equals(dataList.get(n)[0])){
		 						temp.put("A","NA");
		 					}else{
		 						temp.put("A",String.valueOf(Float.valueOf(dataList.get(n)[0]) * count.get(compute) / string.length()));
		 					}
		 					break;
		 				case "R" :
		 					if("NA".equals(dataList.get(n)[1])){
		 						temp.put("R","NA");
		 					}else{
		 						temp.put("R",String.valueOf(Float.valueOf(dataList.get(n)[1]) * count.get(compute) / string.length()));
		 					}
		 					break;
		 				case "N" :
		 					if("NA".equals(dataList.get(n)[2])){
		 						temp.put("N","NA");
		 					}else{
		 						temp.put("N",String.valueOf(Float.valueOf(dataList.get(n)[2]) * count.get(compute) / string.length()));
		 					}
		 					break;
		 				case "D" :
		 					if("NA".equals(dataList.get(n)[3])){
		 						temp.put("D","NA");
		 					}else{
		 						temp.put("D",String.valueOf(Float.valueOf(dataList.get(n)[3]) * count.get(compute) / string.length()));
		 					}
		 					break;
		 				case "C" :
		 					if("NA".equals(dataList.get(n)[4])){
		 						temp.put("C","NA");
		 					}else{
		 						temp.put("C",String.valueOf(Float.valueOf(dataList.get(n)[4]) * count.get(compute) / string.length()));
		 					}
		 					break;
		 				case "Q" :
		 					if("NA".equals(dataList.get(n)[5])){
		 						temp.put("Q","NA");
		 					}else{
		 						temp.put("Q",String.valueOf(Float.valueOf(dataList.get(n)[5]) * count.get(compute) / string.length()));
		 					}
		 					break;
		 				case "E" :
		 					if("NA".equals(dataList.get(n)[6])){
		 						temp.put("E","NA");
		 					}else{
		 						temp.put("E",String.valueOf(Float.valueOf(dataList.get(n)[6]) * count.get(compute) / string.length()));
		 					}
		 					break;
		 				case "G" :
		 					if("NA".equals(dataList.get(n)[7])){
		 						temp.put("G","NA");
		 					}else{
		 						temp.put("G",String.valueOf(Float.valueOf(dataList.get(n)[7]) * count.get(compute) / string.length()));
		 					}
		 					break;
		 				case "H" :
		 					if("NA".equals(dataList.get(n)[8])){
		 						temp.put("H","NA");
		 					}else{
		 						temp.put("H",String.valueOf(Float.valueOf(dataList.get(n)[8]) * count.get(compute) / string.length()));
		 					}
		 					break;
		 				case "I" :
		 					if("NA".equals(dataList.get(n)[9])){
		 						temp.put("I","NA");
		 					}else{
		 						temp.put("I",String.valueOf(Float.valueOf(dataList.get(n)[9]) * count.get(compute) / string.length()));
		 					}
		 					break;
		 				case "L" :
		 					if("NA".equals(dataList.get(n)[10])){
		 						temp.put("L","NA");
		 					}else{
		 						temp.put("L",String.valueOf(Float.valueOf(dataList.get(n)[10]) * count.get(compute) / string.length()));
		 					}
		 					break;
		 				case "K" :
		 					if("NA".equals(dataList.get(n)[11])){
		 						temp.put("K","NA");
		 					}else{
		 						temp.put("K",String.valueOf(Float.valueOf(dataList.get(n)[11]) * count.get(compute) / string.length()));
		 					}
		 					break;
		 				case "M" :
		 					if("NA".equals(dataList.get(n)[12])){
		 						temp.put("M","NA");
		 					}else{
		 						temp.put("M",String.valueOf(Float.valueOf(dataList.get(n)[12]) * count.get(compute) / string.length()));
		 					}
		 					break;
		 				case "F" :
		 					if("NA".equals(dataList.get(n)[13])){
		 						temp.put("F","NA");
		 					}else{
		 						temp.put("F",String.valueOf(Float.valueOf(dataList.get(n)[13]) * count.get(compute) / string.length()));
		 					}
		 					break;
		 				case "P" :
		 					if("NA".equals(dataList.get(n)[14])){
		 						temp.put("P","NA");
		 					}else{
		 						temp.put("P",String.valueOf(Float.valueOf(dataList.get(n)[14]) * count.get(compute) / string.length()));
		 					}
		 					break;
		 				case "S" :
		 					if("NA".equals(dataList.get(n)[15])){
		 						temp.put("S","NA");
		 					}else{
		 						temp.put("S",String.valueOf(Float.valueOf(dataList.get(n)[15]) * count.get(compute) / string.length()));
		 					}
		 					break;
		 				case "T" :
		 					if("NA".equals(dataList.get(n)[16])){
		 						temp.put("T","NA");
		 					}else{
		 						temp.put("T",String.valueOf(Float.valueOf(dataList.get(n)[16]) * count.get(compute) / string.length()));
		 					}
		 					break;
		 				case "W" :
		 					if("NA".equals(dataList.get(n)[17])){
		 						temp.put("W","NA");
		 					}else{
		 						temp.put("W",String.valueOf(Float.valueOf(dataList.get(n)[17]) * count.get(compute) / string.length()));
		 					}
		 					break;
		 				case "Y" :
		 					if("NA".equals(dataList.get(n)[18])){
		 						temp.put("Y","NA");
		 					}else{
		 						temp.put("Y",String.valueOf(Float.valueOf(dataList.get(n)[18]) * count.get(compute) / string.length()));
		 					}
		 					break;
		 				case "V" :
		 					if("NA".equals(dataList.get(n)[19])){
		 						temp.put("V","NA");
		 					}else{
		 						temp.put("V",String.valueOf(Float.valueOf(dataList.get(n)[19]) * count.get(compute) / string.length()));
		 					}
		 					break;
		 				}
		 			}
		 			
		 			for (int l = 0; l < dataList.get(n).length; l++) {
		 				if("NA".equals(dataList.get(n)[l])){
		 					temp.put(fasta[l],"NA");
		 				}
					}
		 			
		 			if(temp.get("A") == null ){
		 				csvstr.append("0.0,");
		 			}else if(!"NA".equals(temp.get("A"))){
		 				csvstr.append(temp.get("A")).append(",");
		 			}
		 			if(temp.get("R") == null ){
		 				csvstr.append("0.0,");
		 			}else if(!"NA".equals(temp.get("R"))){
		 				csvstr.append(temp.get("R")).append(",");
		 			}
		 			if(temp.get("N") == null ){
		 				csvstr.append("0.0,");
		 			}else if(!"NA".equals(temp.get("N"))){
		 				csvstr.append(temp.get("N")).append(",");
		 			}
		 			if(temp.get("D") == null ){
		 				csvstr.append("0.0,");
		 			}else if(!"NA".equals(temp.get("D"))){
		 				csvstr.append(temp.get("D")).append(",");
		 			}
		 			if(temp.get("C") == null ){
		 				csvstr.append("0.0,");
		 			}else if(!"NA".equals(temp.get("C"))){
		 				csvstr.append(temp.get("C")).append(",");
		 			}
		 			if(temp.get("Q") == null ){
		 				csvstr.append("0.0,");
		 			}else if(!"NA".equals(temp.get("Q"))){
		 				csvstr.append(temp.get("Q")).append(",");
		 			}
		 			if(temp.get("E") == null ){
		 				csvstr.append("0.0,");
		 			}else if(!"NA".equals(temp.get("E"))){
		 				csvstr.append(temp.get("E")).append(",");
		 			}
		 			if(temp.get("G") == null ){
		 				csvstr.append("0.0,");
		 			}else if(!"NA".equals(temp.get("G"))){
		 				csvstr.append(temp.get("G")).append(",");
		 			}
		 			if(temp.get("H") == null ){
		 				csvstr.append("0.0,");
		 			}else if(!"NA".equals(temp.get("H"))){
		 				csvstr.append(temp.get("H")).append(",");
		 			}
		 			if(temp.get("I") == null ){
		 				csvstr.append("0.0,");
		 			}else if(!"NA".equals(temp.get("I"))){
		 				csvstr.append(temp.get("I")).append(",");
		 			}
		 			if(temp.get("L") == null ){
		 				csvstr.append("0.0,");
		 			}else if(!"NA".equals(temp.get("L"))){
		 				csvstr.append(temp.get("L")).append(",");
		 			}
		 			if(temp.get("K") == null ){
		 				csvstr.append("0.0,");
		 			}else if(!"NA".equals(temp.get("K"))){
		 				csvstr.append(temp.get("K")).append(",");
		 			}
		 			if(temp.get("M") == null ){
		 				csvstr.append("0.0,");
		 			}else if(!"NA".equals(temp.get("M"))){
		 				csvstr.append(temp.get("M")).append(",");
		 			}
		 			if(temp.get("F") == null ){
		 				csvstr.append("0.0,");
		 			}else if(!"NA".equals(temp.get("F"))){
		 				csvstr.append(temp.get("F")).append(",");
		 			}
		 			if(temp.get("P") == null ){
		 				csvstr.append("0.0,");
		 			}else if(!"NA".equals(temp.get("P"))){
		 				csvstr.append(temp.get("P")).append(",");
		 			}
		 			if(temp.get("S") == null ){
		 				csvstr.append("0.0,");
		 			}else if(!"NA".equals(temp.get("S"))){
		 				csvstr.append(temp.get("S")).append(",");
		 			}
		 			if(temp.get("T") == null ){
		 				csvstr.append("0.0,");
		 			}else if(!"NA".equals(temp.get("T"))){
		 				csvstr.append(temp.get("T")).append(",");
		 			}
		 			if(temp.get("W") == null ){
		 				csvstr.append("0.0,");
		 			}else if(!"NA".equals(temp.get("W"))){
		 				csvstr.append(temp.get("W")).append(",");
		 			}
		 			if(temp.get("Y") == null ){
		 				csvstr.append("0.0,");
		 			}else if(!"NA".equals(temp.get("Y"))){
		 				csvstr.append(temp.get("Y")).append(",");
		 			}
		 			if(temp.get("V") == null ){
		 				csvstr.append("0.0,");
		 			}else if(!"NA".equals(temp.get("V"))){
		 				csvstr.append(temp.get("V"));
		 				if(n!=591||e!=1){
		 					csvstr.append(",");
		 				}
		 			}
		 		}
			}
		    csvstr.append("\r\n");
		    fw.write(csvstr.toString());
 			fw.flush();
		}
		 fw.close();
	}
}
