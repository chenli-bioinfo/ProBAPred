﻿

import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class FeatureName {
	
	public static List<String> add(){
		List<String> list = new ArrayList<String>();
		list.add("1AHW_AB:C");
		list.add("1BJ1_HL:VW");
		list.add("1BVK_DE:F");
		list.add("1DQJ_AB:C");
		list.add("1E6J_HL:P");
		list.add("1FSK_BC:A");
		list.add("1JPS_HL:T");
		list.add("1KXQ_H:A");
		list.add("1NCA_HL:N");
		list.add("1P2C_AB:C");
		list.add("1VFB_AB:C");
		list.add("1WEJ_HL:F");
		list.add("2I25_N:L");
		list.add("2JEL_HL:P");
		list.add("2VIR_AB:C");
		list.add("1ACB_E:I");
		list.add("1AVX_A:B");
		list.add("1BRS_A:D");
		list.add("1BUH_A:B");
		list.add("1BVN_P:T");
		list.add("1DFJ_E:I");
		list.add("1EAW_A:B");
		list.add("1EMV_A:B");
		list.add("1EZU_C:AB");
		list.add("1F34_A:B");
		list.add("1FLE_E:I");
		list.add("1GXD_A:C");
		list.add("1JIW_P:I");
		list.add("1JTG_B:A");
		list.add("1MAH_A:F");
		list.add("1NB5_AP:I");
		list.add("1OPH_A:B");
		list.add("1PXV_A:C");
		list.add("1R0R_E:I");
		list.add("1YVB_A:I");
		list.add("1ZLI_A:B");
		list.add("2ABZ_B:E");
		list.add("2B42_A:B");
		list.add("2J0T_A:D");
		list.add("2O3B_A:B");
		list.add("2OUL_A:B");
		list.add("2PTC_E:I");
		list.add("2SIC_E:I");
		list.add("2SNI_E:I");
		list.add("2UUY_A:B");
		list.add("3SGB_E:I");
		list.add("1E6E_A:B");
		list.add("1EWY_A:C");
		list.add("1F6M_A:C");
		list.add("1GLA_G:F");
		list.add("1IJK_A:BC");
		list.add("1JMO_A:HL");
		list.add("1JWH_CD:A");
		list.add("1KKL_ABC:H");
		list.add("1M10_A:B");
		list.add("1NW9_B:A");
		list.add("1OC0_A:B");
		list.add("1R6Q_A:C");
		list.add("1US7_A:B");
		list.add("1WDW_BD:A");
		list.add("1ZM4_A:B");
		list.add("2A9K_A:B");
		list.add("2MTA_HL:A");
		list.add("2OOB_A:B");
		list.add("2OOR_AB:C");
		list.add("2PCC_A:B");
		list.add("1A2K_C:AB");
		list.add("1E96_A:B");
		list.add("1FQJ_A:B");
		list.add("1GRN_A:B");
		list.add("1HE8_B:A");
		list.add("1I2M_A:B");
		list.add("1I4D_D:AB");
		list.add("1IBR_A:B");
		list.add("1K5D_AB:C");
		list.add("1LFD_B:A");
		list.add("1NVU_Q:S");
		list.add("1WQ1_R:G");
		list.add("1Z0K_A:B");
		list.add("2FJU_B:A");
		list.add("3CPH_G:A");
		list.add("1NVU_R:S");
		list.add("1E4K_AB:C");
		list.add("1EER_A:BC");
		list.add("1HCF_AB:X");
		list.add("1KAC_A:B");
		list.add("1KTZ_A:B");
		list.add("1PVH_A:B");
		list.add("1RV6_VW:X");
		list.add("1T6B_X:Y");
		list.add("2AJF_A:E");
		list.add("2HLE_A:B");
		list.add("2I9B_E:A");
		list.add("2NYZ_AB:D");
		list.add("1MLC_AB:E");
		list.add("2VIS_AB:C");
		list.add("1AY7_A:B");
		list.add("1CBW_ABC:D");
		list.add("2PCB_A:B");
		list.add("2TGP_Z:I");
		list.add("2WPT_A:B");
		list.add("1AVZ_B:C");
		list.add("2AQ3_A:B");
		list.add("1ATN_A:D");
		list.add("1DE4_AB:CF");
		list.add("1FC2_C:D");
		list.add("1H1V_A:G");
		list.add("1IB1_AB:E");
		list.add("1KLU_AB:D");
		list.add("1KXP_A:D");
		list.add("1XQS_A:C");
		list.add("2B4J_AB:C");
		list.add("2C0L_A:B");
		list.add("2VDB_A:B");
		list.add("1AKJ_AB:DE");
		list.add("1MQ8_A:B");
		list.add("1RLB_ABCD:E");
		list.add("1XD3_A:B");
		list.add("1ZHI_A:B");
		list.add("2BTF_A:P");
		list.add("2HQS_A:H");
		list.add("2HRK_A:B");
		list.add("2OZA_B:A");
		list.add("3BP8_AB:C");
		list.add("1AK4_A:D");
		list.add("1B6C_A:B");
		list.add("1EFN_B:A");
		list.add("1FFW_A:B");
		list.add("1GCQ_B:C");
		list.add("1GPW_A:B");
		list.add("1H9D_A:B");
		list.add("1QA9_A:B");
		list.add("1S1Q_A:B");
		list.add("2GOX_A:B");
		list.add("3BZD_A:B");
		return list;
	}
	
	
	
	public static void main(String[] args) throws IOException {
		 String [] fasta =new String[]{"A", "R","N","D","C","Q","E","G","H","I","L","K","M","F","P","S","T","W","Y","V",};
			FileWriter fw = new FileWriter("C:\\FeatureName.csv");
			StringBuffer csvstr = new StringBuffer();
			List<String> list = add();
			for (String string : list) {
				String  pdb=string.substring(0, 4);
				String	former = null ;
				String	latter = null ;
				Pattern pattern3 = Pattern.compile("\\w{5}(\\w*)[:](\\w*)");//解析2个蛋白质
				Matcher matcher3 = pattern3.matcher(string);
				if(matcher3.find()){
					former = matcher3.group(1);
					latter = matcher3.group(2);
				}
				
				for (int i = 0; i < 544; i++) {
					for (int j = 0; j < fasta.length; j++) {
						String temp = "ligand" + "_" + "AAindex" + "_" + (i+1) + "_" + fasta[j];
						csvstr.append(temp).append(",");
					}
					for (int j = 0; j < fasta.length; j++) {
						String temp = "receptor" + "_" + "AAindex" + "_" + (i+1) + "_" + fasta[j];
						csvstr.append(temp).append(",");
					}
				}
				
				for (int i = 0; i < 48; i++) {
					for (int j = 0; j < fasta.length; j++) {
						String temp = "ligand" + "_" + "literature" + "_" + (i+1) + "_" + fasta[j];
						csvstr.append(temp).append(",");
					}
					for (int j = 0; j < fasta.length; j++) {
						String temp = "receptor" + "_" + "literature" + "_" + (i+1) + "_" + fasta[j];
						csvstr.append(temp).append(",");
					}
				}
			}
		    fw.write(csvstr.toString());
		    fw.flush();
		    fw.close();
		    System.out.println("OK");
	}
}
