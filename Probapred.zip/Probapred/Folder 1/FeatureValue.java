package t999999;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class FeatureValue {
	
	public static List<String> add(){
		List<String> list = new ArrayList<String>();
		list.add("1AHW_AB:C");
		return list;
	}
	
	public static List<String> featureName(){
		List<String> list = new ArrayList<String>();
		list.add("r_AAindex_25_F");	
		list.add("l_AAindex_35_R");	
		list.add("l_AAindex_36_Q");	
		list.add("l_AAindex_50_W");	
		list.add("r_AAindex_50_L");	
		list.add("l_AAindex_51_M");	
		list.add("r_AAindex_55_P");	
		list.add("r_AAindex_85_L");	
		list.add("r_AAindex_85_F");	
		list.add("l_AAindex_134_N");
		list.add("r_AAindex_134_C");
		list.add("l_AAindex_250_M");
		list.add("l_AAindex_260_W");
		list.add("l_AAindex_261_R");
		list.add("l_AAindex_273_R");
		list.add("l_AAindex_281_E");
		list.add("l_AAindex_286_M");
		list.add("l_AAindex_296_R");
		list.add("l_AAindex_315_N");
		list.add("l_AAindex_358_N");
		list.add("r_AAindex_360_F");
		list.add("r_AAindex_361_L");
		list.add("r_AAindex_361_P");
		list.add("l_AAindex_379_N");
		list.add("l_AAindex_379_G");
		list.add("l_AAindex_387_M");
		list.add("r_AAindex_397_F");
		list.add("r_AAindex_454_F");
		list.add("l_AAindex_486_N");
		list.add("l_AAindex_486_G");
		list.add("r_AAindex_495_P");
		list.add("l_AAindex_497_R");
		list.add("l_AAindex_497_Q");
		list.add("l_AAindex_497_G");
		list.add("l_AAindex_497_S");
		list.add("r_AAindex_497_S");
		list.add("l_AAindex_499_G");
		list.add("l_AAindex_513_M");
		list.add("l_AAindex_523_W");	
		return list;
	}
	
	public static List<Float> AAvalue(){
		List<Float> list = new ArrayList<Float>();
		list.add((float)0.015);	
		list.add((float)0.01);	
		list.add((float)0.01);	
		list.add((float)0.013);	
		list.add((float)0.025);	
		list.add((float)0.014);	
		list.add((float)-0.01);	
		list.add((float)-0.01);	
		list.add((float)0.03);	
		list.add((float)0.043);	
		list.add((float)0.02);	
		list.add((float)0.054);	
		list.add((float)-0.02);	
		list.add((float)-0.03);	
		list.add((float)0.03);	
		list.add((float)-0.05);	
		list.add((float)-0.01);	
		list.add((float)-0.01);	
		list.add((float)-0.01);	
		list.add((float)-0.01);	
		list.add((float)-0.011);	
		list.add((float)-0.008);	
		list.add((float)-0.016);	
		list.add((float)0.00359);	
		list.add((float)0.00499);	
		list.add((float)0.03);	
		list.add((float)0.001);	
		list.add((float)-0.01);	
		list.add((float)0.0036);	
		list.add((float)0.005);	
		list.add((float)0.0019);	
		list.add((float)-0.0103);	
		list.add((float)0.0246);	
		list.add((float)0.0248);	
		list.add((float)0.004);	
		list.add((float)0.004);	
		list.add((float)0.01);	
		list.add((float)0.0197);	
		list.add((float)0.05);
		return list;
	}
	
	public static Map<String, Float> CountMap(String string) {
		Map<String, Float> count = new HashMap<String, Float>();
		    for(int i=0;i<string.length();i++){ 	 //计数
				  String subStr = string.substring(i, i+1);
				  if(!count.containsKey(subStr)){
					 count.put(subStr,  (float) 1);
				  }else{
					 count.put(subStr, count.get(subStr)+1);
				  }
		    }
		return count;
	}
	
	public static void main(String[] args) throws Exception{
		
		Map<String, String> temp = new HashMap<String, String>();//key是特征名称，value是特征值
		List<List<String>> chainList = new ArrayList<List<String>>();//氨基酸链队列
		List<String> list = add();//蛋白质名称队列
		List<String> featureNameList = featureName();//特征名字队列
		List<Float> AAvalueList = AAvalue();//AAindex的值队列
		for (int i = 0; i < list.size(); i++) {
			List<String> list2 = new ArrayList<String>();
			String pdb=list.get(i).substring(0, 4);
			URL url = new URL("http://www.rcsb.org/pdb/download/viewFastaFiles.do?structureIdList=" + pdb + "&compressionType=uncompressed");//扒页面
			BufferedReader br = new BufferedReader(new InputStreamReader(url.openStream()));
			String line = null;
			StringBuffer allaqe = new StringBuffer();
			while(null != (line = br.readLine())){
				allaqe.append(line.replaceAll("\\|", ""));
			}
			br.close();
		//	System.out.println("获得该pdb的页面内容\n"+allaqe);
			
			String	former = null ;
			String	latter = null ;
			Pattern pattern3 = Pattern.compile("\\w{5}(\\w*)[:](\\w*)");//解析2个蛋白质
			Matcher matcher3 = pattern3.matcher(list.get(i));
			if(matcher3.find()){
				former = matcher3.group(1);
				latter = matcher3.group(2);
			}
			
			String former1Temp = "";
			char[] former1 = former.toCharArray();//前一种的蛋白质chain
		    for (int j = 0;j < former1.length;j ++){
		    	String regex = "(>"+pdb+")[:]("+String.valueOf(former1[j])+"PDBIDCHAINSEQUENCE)(\\w*)";
		    	Pattern pattern2 = Pattern.compile(regex);
				Matcher matcher2 = pattern2.matcher(allaqe);
				if(matcher2.find()){
					former1Temp = former1Temp + matcher2.group(3);
				}
					
		    }
		    list2.add(former1Temp);
		    
		    String latter2Temp = "";
		    char[] latter2 = latter.toCharArray();//后一种的蛋白质chain
		    for (int k = 0;k < latter2.length;k ++){
		    	String regex = "(>"+pdb+")[:]("+String.valueOf(latter2[k])+"PDBIDCHAINSEQUENCE)(\\w*)";
		    	Pattern pattern2 = Pattern.compile(regex);
				Matcher matcher2 = pattern2.matcher(allaqe);
				if(matcher2.find()){
					latter2Temp = latter2Temp + matcher2.group(3);
				}
		    }
		    list2.add(latter2Temp);
		    
			chainList.add(list2);
		 }
		
		 
		 for(int d = 0; d < chainList.size(); d++){
		    List<String> test = chainList.get(d);
		    
	    	String string1= test.get(0);
	    	Map<String, Float> count1 = CountMap(string1);
	    	
	    	String string2= test.get(1);
	    	Map<String, Float> count2 = CountMap(string2);
	 		 for (int n = 0; n < featureNameList.size(); n++) {
	 			 String first = featureNameList.get(n).substring(0,1);
	 			 String last = featureNameList.get(n).substring(featureNameList.get(n).length()-1, featureNameList.get(n).length());
	 			 if("l".equals(first)){
	 				temp.put(featureNameList.get(n), String.valueOf(Float.valueOf(AAvalueList.get(n)) * count1.get(last) / string1.length()));
	 			 }
	 			 if("r".equals(first)){
	 				temp.put(featureNameList.get(n), String.valueOf(Float.valueOf(AAvalueList.get(n)) * count2.get(last) / string2.length()));
	 			 }
	 		}
		 }
		 
		 for (int n = 0; n < featureNameList.size(); n++) {
		 System.out.println("feature name:" + featureNameList.get(n) + "feature value:" + temp.get(featureNameList.get(n)));
		 }
	  }
}
