Folder 1: The FeatureValue.java file can calculate the 53 sequence features value, README.txt includes calculation procedure description

Folder 2: 48.txt and 544.txt are collected from other literatures. The SequenceFeatureCalculation.java can calculate sequence features value. AllSequenceFeaturesOfTrainingSet.csv includes 23650 sequence features. README.txt includes calculation procedure description

Folder 3: The folder includes three feature sets which were obtained by three Feature selection methods

Supplementary material: It contains the supplementary material of the article

Feature data of test set.csv: It is feature data of test set. Its feature name as same as the feature name of second feature set

Source codes and user instruction .docx: The doc file includes calculation procedure description of structure features and MARS

ARESLab.zip and arescv.m: They are the package and file which were needed to build the MARS model